package com.xiaba2.cms.dao;

import java.util.UUID;

import com.xiaba2.cms.domain.ArticleBody;
import com.xiaba2.core.IBaseDao;

public interface IArticleBodyDao extends IBaseDao<ArticleBody, UUID> {

}
