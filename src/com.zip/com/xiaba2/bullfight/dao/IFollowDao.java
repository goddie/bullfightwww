package com.xiaba2.bullfight.dao;
import java.util.UUID;
import com.xiaba2.bullfight.domain.Follow;
import com.xiaba2.core.IBaseDao;
public interface IFollowDao extends IBaseDao<Follow, UUID> {
}