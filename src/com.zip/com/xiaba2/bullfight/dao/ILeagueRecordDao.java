package com.xiaba2.bullfight.dao;
import java.util.UUID;
import com.xiaba2.bullfight.domain.LeagueRecord;
import com.xiaba2.core.IBaseDao;
public interface ILeagueRecordDao extends IBaseDao<LeagueRecord, UUID> {
}