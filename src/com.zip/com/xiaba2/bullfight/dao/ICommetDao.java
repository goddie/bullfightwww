package com.xiaba2.bullfight.dao;
import java.util.UUID;
import com.xiaba2.bullfight.domain.Commet;
import com.xiaba2.core.IBaseDao;
public interface ICommetDao extends IBaseDao<Commet, UUID> {
}