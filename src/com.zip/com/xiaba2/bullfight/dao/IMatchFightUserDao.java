package com.xiaba2.bullfight.dao;
import java.util.UUID;
import com.xiaba2.bullfight.domain.MatchFightUser;
import com.xiaba2.core.IBaseDao;
public interface IMatchFightUserDao extends IBaseDao<MatchFightUser, UUID> {
}