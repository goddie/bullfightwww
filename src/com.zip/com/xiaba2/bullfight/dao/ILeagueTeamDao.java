package com.xiaba2.bullfight.dao;
import java.util.UUID;
import com.xiaba2.bullfight.domain.LeagueTeam;
import com.xiaba2.core.IBaseDao;
public interface ILeagueTeamDao extends IBaseDao<LeagueTeam, UUID> {
}