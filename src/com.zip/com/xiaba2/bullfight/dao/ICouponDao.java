package com.xiaba2.bullfight.dao;
import java.util.UUID;
import com.xiaba2.bullfight.domain.Coupon;
import com.xiaba2.core.IBaseDao;
public interface ICouponDao extends IBaseDao<Coupon, UUID> {
}