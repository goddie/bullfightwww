package com.xiaba2.bullfight.dao;
import java.util.UUID;
import com.xiaba2.bullfight.domain.MatchFight;
import com.xiaba2.core.IBaseDao;
public interface IMatchFightDao extends IBaseDao<MatchFight, UUID> {
}