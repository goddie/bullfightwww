package com.xiaba2.bullfight.dao;
import java.util.UUID;
import com.xiaba2.bullfight.domain.PayRecord;
import com.xiaba2.core.IBaseDao;
public interface IPayRecordDao extends IBaseDao<PayRecord, UUID> {
}