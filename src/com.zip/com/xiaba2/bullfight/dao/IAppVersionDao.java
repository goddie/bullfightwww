package com.xiaba2.bullfight.dao;
import java.util.UUID;
import com.xiaba2.bullfight.domain.AppVersion;
import com.xiaba2.core.IBaseDao;
public interface IAppVersionDao extends IBaseDao<AppVersion, UUID> {
}