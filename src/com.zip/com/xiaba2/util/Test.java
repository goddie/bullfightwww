package com.xiaba2.util;

public class Test {
public static void main(String[] args)
{
	System.out.println( HttpUtil.uuidMysqlString("50A5DFE66BD74436B8A0A9D912D28CBB"));
}
}
